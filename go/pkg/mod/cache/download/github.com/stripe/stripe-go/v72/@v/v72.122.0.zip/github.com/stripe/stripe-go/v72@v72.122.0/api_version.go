//
//
// File generated from our OpenAPI spec
//
//

package stripe

const (
	apiVersion string = "2020-08-27"
)

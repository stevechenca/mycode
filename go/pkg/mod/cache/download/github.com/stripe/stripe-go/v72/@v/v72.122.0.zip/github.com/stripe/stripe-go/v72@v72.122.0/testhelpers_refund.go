//
//
// File generated from our OpenAPI spec
//
//

package stripe

// Expire a refund with a status of requires_action.
type TestHelpersRefundExpireParams struct {
	Params `form:"*"`
}

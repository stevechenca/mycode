// Package recipienttransfer provides the /recipient_transfers APIs
package recipienttransfer

// This object can only be returned/expanded on Balance Transactions
// The API doesn't support retrieve/update/list for those.
